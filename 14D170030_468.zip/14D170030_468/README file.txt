CS101-2015 PROJECT

PROJECT TITLE:RAILWAY STATION MANAGEMENT SYSTEM

GROUP NUMBER: 468

TEAM MEMBERS:
SHIVASUBRAMANIAN            14D170030
SIVA KIRAN                                    140110080             
YOGESH KUMAR                     140010030     
 SANTHOSH KORRA               140110090
�

 
INSTRUCTIONS TO SETUP THE PROJECT:
1.The system must contain a proper codeblocks version with a simlecpp
  compiler or else he can have a simpleblocks version.
2.The simplecpp version must be in working condition.
3.Then copy the code from the file and paste it on the window.
4.Then save the code and run the code.
5.The user will be viewing two windows, one is the grid where he have to
  select the operation he want to perform and the other is the complier
  where he have to give the inputs for the operation and he will get the
  desired result to the operation

CAST VIDEO YOUTUBE LINK:
 https://www.youtube.com/channel/UCE5j8sWpBq10U4VXGCnTHmQ