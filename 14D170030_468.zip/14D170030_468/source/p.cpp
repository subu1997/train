#include<simplecpp>
#include<windows.h>
main_program
{
    initCanvas("POKER" , 1350 , 700);

    Text t1(675 , 100 , "TEXAS HOLD'EM POKER");
    Rectangle r1(675 , 400 , 700 , 400);
    Rectangle r2(480 , 300 , 200  , 50);
    r2.setColor(COLOR("yellow"));
    Rectangle r3(480 , 400 , 200 , 50);
    r3.setColor(COLOR("red"));
    Rectangle r4(480 , 500 , 200 , 50);
    r4.setColor(COLOR("blue"));
    Text t2(480 , 300 , "PLAY");
    Text t3(480 , 400 , "INSTRUCTIONS");
    Text t4(480 , 500 , "QUIT");
    Text t5(800 , 400 , "LEARN MORE ABOUT POKER");
    Text t6(800 , 420 , "www.thepokerbank.com");
    t6.setColor(COLOR("blue"));

        while(1)
        {
        int w = getClick();
        if((w/65536)<580 && (w/65536)>380 && (w%65536)>275 && (w%65536)<325)
        {

          initCanvas("POKER GAME",1350,700);
          wait(10);
        }
        if((w/65536)<580 && (w/65536)>380 && (w%65536)>375 && (w%65536)<425)
        {
            MessageBox(NULL,"1. At the start of the round the deck is shuffled.\n 2. The player begins the game as the dealer.\n 3. At the start of a round the system deals each player 2 cards from the top of the deck.\n 4. The system automatically subtracts the small and big blind dollar amount from the player to the left ofthe dealer and the player two to the left of the dealer, respectively, and places the money into the pot.\n 5. The first stage of betting begins, the player three to the dealer begins by either folding, calling, or raising.\n 6. The first stage of betting continues and gives each consecutive player in a clockwise rotation the optionto fold, call, or raise.\n 7. Once every player calls or folds, the first round of betting ends.\n 8. The system then places the flop face up in the center of the table. \n 9. The second stage of betting ensues beginning with the player to the left of the dealer and moving clockwise giving each consecutive player the option to fold, call, or raise.\n 10. Once every player calls or folds, the second stage of betting ends.\n 11. The system places the turn face up in the center of the table alongside the flop.\n 12. A third stage of betting ensues beginning with the player to the left of the dealer and moving clockwisegiving each consecutive player the option to fold, call, or raise.\n 13. Once every player calls or folds, the third stage of betting ends.\n 14. The system places the river face up in the center of the table alongside the flop and turn.\n 15. A fourth stage of betting ensues beginning with the player to the left of the dealer and moving clockwisegiving each consecutive player the option to fold, call, or raise.\n 16. Once every player calls or folds, the fourth stage of betting ends.\n 17. If two or more players have not folded after the final stage of betting, the players show their hands andthe player with the best hand takes the pot.\n 18. The maximum a player can bet is the amount of money they currently have remaining.\n 19. If a player bets all their money and two or more players are still betting, the system creates a side pot.All future bets goes into this pot.\n 20. A player who bet all his money can only win the main pot.\n 21. If all but one player folds during a stage of betting, that player receives the pot and a new round starts.\n 22. At the end of the round, the player to the left of the dealer becomes the dealer.\n 23. If a player bets and loses all of their money, they are eliminated from the match, and lose the game.\n 24. If a player wins every other opponents money and every opponent is eliminated, the player wins thegame." ,"RULES OF POKER",MB_OK);

           // initCanvas("INSTRUCTIONS",1350,700);
          //wait(10);

        }



       else if((w/65536)<580 && (w/65536)>380 && (w%65536)>475 && (w%65536)<525)
        {
            break ;

        }


        }

    wait(0.1);}
