#include<string>
#include<iostream>
#include<ctime>
#include<cstring>
#include<stdlib.h>
#include<windows.h>
using namespace std;


struct avail//STORES THE NUMBER OF SEATS WHICH ARE BOOKED
{
    int ac1,ac2,ac3,sleeper;
   avail ()
{ ac1=0;
ac2=0;
ac3=0;
sleeper=0;
}
}av;

struct traindetails//STORES THE DETAILS OF THE TRAIN WHICH SHALL BE RESERVED
{
    char trainname[30];
    char trainnumber[30];
    char from[30];
    char to[30];
    struct time
{
    int hours,mins;//for time
};
struct date
{
    int day,month,year;//for date
};
struct coach
{
    int numberofcoaches,numberofseats;//common details about the coach
    float cost;
};
    time departuretime,arrivaltime;
    date departuredate,arrivaldate;
    coach ac1;
    coach ac2;
    coach ac3;
    coach sleeper;//coach class like sleeper ,first class ac
    traindetails *next1;
traindetails()
{next1=NULL;}

} *train=NULL;
traindetails *traintmp;
void displaytraindetails();
void displaytraindetails()//TO DISPLAY THE DETAILS OF THE TRAIN
{cout<<"train name :";
                      cout<<traintmp->trainname<<"\n\n";

                      cout<<"  THE TRAIN NUMBER IS   :";
                      cout<<traintmp->trainnumber<<"\n\n";
                      cout<<"  THE STATION IT IS DEPARTING FROM :";
                      cout<<traintmp->from<<"\n\n";
                      cout<<"  THE STATION IT IS ARRIVING AT :";
                      cout<<traintmp->to<<"\n\n";
                      cout<<"  THE DEPARTURE TIME IN HH:MM FORMAT:";
                      cout<<traintmp->departuretime.hours;
                      cout<<":";
                      cout<<traintmp->departuretime.mins<<"\n\n";
                      cout<<"  THE ARRIVAL TIME IN HH:MM FORMAT :";
                      cout<<traintmp->arrivaltime.hours;
                      cout<<":";
                      cout<<traintmp->arrivaltime.mins <<"\n\n";
                      cout<<"  DEPARTURE DATE IN DD:MM:YY FORMAT :";
                      cout<<traintmp->departuredate.day;
                      cout<<":";
                      cout<<traintmp->departuredate.month;
                      cout<<":";
                      cout<<traintmp->departuredate.year<<"\n\n";
                      cout<<"  ARRIVAL DATE IN DD:MM:YY FORMAT :";
                      cout<<traintmp->arrivaldate.day;
                      cout<<":";
                      cout<<traintmp->arrivaldate.month;
                      cout<<":";
                      cout<<traintmp->arrivaldate.year<<"\n\n";

}
struct ticketdetails//TO STORE THE DETAILS OF THE TICKET
{
     char trainnumber[100];
     char passengername[30];
     char sex;
     int coachno;//is different from total no of coaches it like 10 of s10 ,4 of b4
     int seatno;
     int coach;//which class like ac or sleeper 1-ac1 2-ac2 like that
     int age;
     int status;
     ticketdetails *next2;
      ticketdetails()
          {next2=NULL;}

} *ticket=NULL;//for storing the initial address
ticketdetails *tickettmp;//for accessing the link list
void countseats(char tno[100])//taking the train number if ticket!=null//nothing changes
{ ticketdetails *tmp;
av.ac1=0;
av.ac2=0;
av.ac3=0;
av.sleeper=0;
    tmp=ticket;
    while(tmp!=NULL)
    {
         if((strcmp(tno,tmp->trainnumber)==0)&&(tmp->coach==1)&&(tmp->status==1))
         {
             av.ac1++;
         }
          if((strcmp(tno,tmp->trainnumber)==0)&&(tmp->coach==2)&&(tmp->status==1))
         {

             av.ac2++;
         }
           if((strcmp(tno,tmp->trainnumber)==0)&&(tmp->coach==3)&&(tmp->status==1))
         {

             av.ac3++;
         }
           if((strcmp(tno,tmp->trainnumber)==0)&&(tmp->coach==4)&&(tmp->status==1))
         {

             av.sleeper++;
         }
    tmp=tmp->next2;
    }
}
int wait;
void waiting(int a)//COUNT THE NUMBER OF TICKETS IN WAITING LIST BUT CHANGES THE POINTER TICKETTMP

 {    wait=0;
     tickettmp=ticket;
     while(tickettmp!=NULL)
     {
         if(strcmp(tickettmp->trainnumber,traintmp->trainnumber)==0&&tickettmp->status==2&&tickettmp->coach==a)
            wait++;
          tickettmp=tickettmp->next2;
     }
   cout<<wait;
 }
void rearrange(int a,char tno[30]) //WILL ARRANGE THE LINKLIST IN THE ORDER OF BOOKED , WAITING BUT CHANGES THE POINTER TICKETTMP
                                   //passing the train number and the class like sleeper ,ac rearranges the waiting and the cancelled ticket
   { ticketdetails *cancelled;
     int can=0,wat=0;//for indentifying different conditions
    if(ticket!=NULL)
    {  tickettmp=ticket;
       while(tickettmp!=NULL)
       {
          if((tickettmp->status==0)&&(strcmp(tno,tickettmp->trainnumber)==0)&&(tickettmp->coach==a))
             {  can=1;
                cancelled=tickettmp;
                break;
             }
           tickettmp=tickettmp->next2;
       }//cancelled will be pointing the cancelled one
       tickettmp=ticket;
       while(tickettmp!=NULL)
       {
           if((tickettmp->status==2)&&(strcmp(tno,tickettmp->trainnumber)==0)&&(tickettmp->coach==a))
              {   wat=1;
                  break;
              }
           tickettmp=tickettmp->next2;
       }//ticket tmp will be pointing to the waiting
       if(can==1&&wat==1)
       {
           strcpy(cancelled->passengername,tickettmp->passengername);
           cancelled->sex=tickettmp->sex;
           cancelled->status=1;
           cancelled->age=tickettmp->age;
           while(cancelled->next2!=tickettmp)
           {
               cancelled=cancelled->next2;
           }
          cancelled->next2=tickettmp->next2;//deleting the waiting one after it gets confirm
       }
    }
   }
   int ckp=0;
   void traintp(char tnumbr[30])//places the train tmp pointer at the compared place

{traintmp=train;
  ckp=0;
    while(traintmp!=NULL)
    {
        if(strcmp(traintmp->trainnumber,tnumbr)==0)
              {  ckp=1;break;


            }
        traintmp=traintmp->next1;
    }
}

 struct currenttrain//STORES THE DATA OF THE TRAIN WHICH IS ENTERED BY THE ADMIN
   {
     int trainnumber,platformnumber;
    char trainname[30];
    float timeofstay;// time of stay is in seconds
     int  traintype;
     clock_t start;
    currenttrain()
        {
          platformnumber=NULL;
        }
   };
 struct platform//STORES THE TOTAL NUMBER OF PLATFORM
   {
     int expressplatform,localplatform,goodsplatform;
     platform()
       {
           expressplatform=3;
           localplatform=3;
           goodsplatform=3;
        }
   }platform1;
   currenttrain expresstrain[30];//all the objects are in global scope
   currenttrain localtrain[30];
   currenttrain goodstrain[30];
   void allocation(int);//gets the entry of the train, each and every element
                              //in the array has a particular platform or null in them
                              //if it is null then th entry is made in that array element

   void nullallocation(int);//whenever the time of stay of a train gets over
                                 //the platform is allocated to null


   int main()
 {system("cls");
   while(1)
   {
   int option;
   system("cls");
   cout<<"1.STATION LOGIN\n\n";
   cout<<"2.USER LOGIN\n\n";
   cout<<"3.TICKET RESERVATION\n\n";
   cout<<"ENTER THE OPTION \n";
   cin>>option;

   switch(option)

   { case 3:{ system("CLS");


       while(1)

   {

    cout<<"1.ADMIN ENTRY\n\n";//ENTRY BY THE ADMIN FOR ENTERING THE DETAILS OF THE TRAIN FOR RESERVATION
    cout<<"2.USER ENTRY\n\n";//ENTRY FOR THE USER TO CHECK AND RESERVE THE TICKET
    cout<<"3.back\n\n";
    cout<<"ENTER YOUR OPTION\n";
    int option;
    cin>>option;
     if(option>3 || option<1)
        {cout<<"INVALID";
         Sleep(800);
         system("CLS");
        }

     if(option==3)
        break;
    switch(option)
    {
    case 1:
             {   system("CLS");
                 cout<<"1.ENTER THE DETAILS OF THE CURRENT TRAIN TO BE RESERVED\n\n";
                 cout<<"2.DISPLAY THE DETAILS OF THE TRAIN\n\n";
                 cout<<"3.BACK\n\nENTER YOUR OPTION\n\n";//THE USER SHOULD NOT GIVE THE INPUT AS CHARACTERS WHEN THE INPUT IS EXPECTED TO BE INTEGER
                 int option;
                 cin>>option;
                 if(option==3)
                    continue;//goes back
                if(option>3 || option<1)
                   {cout<<"INVALID";
                    Sleep(800);
                    system("CLS");
                   }
                 if(option==1)
                 {


                     if(train!=NULL)
                     {  traintmp=train;
                        while(traintmp->next1!=NULL)
                        {
                            traintmp=traintmp->next1;
                        }

                      traintmp->next1=new traindetails;
                      traintmp=traintmp->next1;
                     }
                      if(train==NULL)
                      {
                        train=new traindetails;
                        traintmp=train;

                      }

                      cout<<"TRAIN NAME  :";
                      cin>>traintmp->trainname;
                      cout<<"\n\n";
                      cout<<"ENTER THE TRAIN NUMBER :";
                      cin>>traintmp->trainnumber;
                      cout<<"\n\n";
                      cout<<" THE STATION IT IS DEPARTING FROM:";
                      cin>>traintmp->from;
                      cout<<"\n\n";
                      cout<<" THE STATION IT  IS ARRIVING AT :";
                      cin>>traintmp->to;
                      cout<<"\n\n";
                      cout<<" DEPARTURE TIME IN HH,MM FORMAT  :";//THE USER HAS TO PRESS ENTER AFTER ENTERING THE HOURS MINUTES AND DATE
                      cin>>traintmp->departuretime.hours;
                      cout<<":";
                      cin>>traintmp->departuretime.mins;
                      cout<<"\n\n";
                      cout<<"ARRIVAL TIME IN HH,MM FORMAT :";
                      cin>>traintmp->arrivaltime.hours;
                      cout<<":";
                      cin>>traintmp->arrivaltime.mins ;
                      cout<<"\n\n";
                      cout<<" DEPARTURE DATE IN DD,MM,YY FORMAT :";
                      cin>>traintmp->departuredate.day;
                      cout<<":";
                      cin>>traintmp->departuredate.month;
                      cout<<":";
                      cin>>traintmp->departuredate.year;
                      cout<<" \n\n";
                      cout<<" ARRIVAL DATE IN DD,MM,YY FORMAT :";
                      cin>>traintmp->arrivaldate.day;
                      cout<<":";
                      cin>>traintmp->arrivaldate.month;
                      cout<<":";
                      cin>>traintmp->arrivaldate.year;
                      cout<<"\n\n";
                      cout<<" NUMBER OF COACHES IN AC FIRST CLASS:";
                      cin>>traintmp->ac1.numberofcoaches;
                      cout<<"\n\n";
                      cout<<" NUMBER OF SEATS IN THE COACH:";
                      cin>>traintmp->ac1.numberofseats;
                      cout<<"\n\n";
                      cout<<" COST OF A SEAT IN THE COACH:";
                      cin>>traintmp->ac1.cost;
                      cout<<"\n\n";
                      cout<<" NUMBER OF COACHES IN AC SECOND CLASS :";
                      cin>>traintmp->ac2.numberofcoaches;
                      cout<<"\n\n";
                      cout<<" NUMBER OF SEATS IN THE COACH :";
                      cin>>traintmp->ac2.numberofseats;
                      cout<<"\n\n";
                      cout<<" COST OF EACH SEAT IN THE COACH :";
                      cin>>traintmp->ac2.cost;
                      cout<<"\n\n";
                      cout<<" NUMBER OF COACHES IN AC THIRD CLASS :";
                      cin>>traintmp->ac3.numberofcoaches;
                      cout<<"\n\n";
                      cout<<" NUMBER OF SEATS IN THE COACH :";
                      cin>>traintmp->ac3.numberofseats;
                      cout<<"\n\n";
                      cout<<" COST OF A SEAT IN THE COACH :";
                      cin>>traintmp->ac3.cost;
                      cout<<"\n\n";
                      cout<<" NUMBER OF COACHES IN SLEEPER CLASS :";
                      cin>>traintmp->sleeper.numberofcoaches;
                      cout<<"\n\n";
                      cout<<" NUMBER OF SEATS IN THE COACH :";
                      cin>>traintmp->sleeper.numberofseats;
                      cout<<"\n\n";
                      cout<<" COST OF A SEAT IN THE COACH :";
                      cin>>traintmp->sleeper.cost;
                      cout<<"\n\n";
                      Sleep(800);

                 }

           if(option==2)
            {
                traintmp=train;
                system("CLS");
                 if(train==NULL)
                       {
                        cout<<"NO TRAIN AVAILABLE \n\n";
                        Sleep(500);
                       }

              if(train!=NULL)//displaying all the trains
                {
                  while(traintmp!=NULL)
                     {
                         displaytraindetails();          //function which displays the details of the train whichever the train tmp is pointing at.
                      cout<<" NUMBER OF COACHES IN AC FIRST CLASS :";
                      cout<<traintmp->ac1.numberofcoaches;
                      cout<<"\n\n";
                      cout<<" NUMBER OF SEATS IN THE COACH :";
                      cout<<traintmp->ac1.numberofseats;
                      cout<<"\n\n";
                      cout<<" COST OF A SEAT IN THE COACH :";
                      cout<<traintmp->ac1.cost;
                      cout<<"\n\n";
                      cout<<" NUMBER OF COACHES IN AC SECOND CLASS :";
                      cout<<traintmp->ac2.numberofcoaches;
                      cout<<"\n\n";
                      cout<<" NUMBER OF SEATS IN THE COACH :";
                      cout<<traintmp->ac2.numberofseats;
                      cout<<"\n\n";
                      cout<<" COST OF A SEAT IN THE COACH :";
                      cout<<traintmp->ac2.cost;
                      cout<<"\n\n";
                      cout<<" NUMBER OF COACHES IN AC THIRD CLASS :";
                      cout<<traintmp->ac3.numberofcoaches;
                      cout<<"\n\n";
                      cout<<" NUMBER OF SEATS IN THE COACH :";
                      cout<<traintmp->ac3.numberofseats;
                      cout<<"\n\n";
                      cout<<" COST OF A SEAT IN THE COACH :";
                      cout<<traintmp->ac3.cost;
                      cout<<"\n\n";
                      cout<<" NUMBER OF COACHES IN SLEEPER CLASS :";
                      cout<<traintmp->sleeper.numberofcoaches;
                      cout<<"\n\n";
                      cout<<" NUMBER OF SEATS IN THE COACh :";
                      cout<<traintmp->sleeper.numberofseats;
                      cout<<"\n\n";
                      cout<<" COST OF A SEAT IN THE COACH :";
                      cout<<traintmp->sleeper.cost;
                      cout<<"\n\n";
                      traintmp=traintmp->next1;
                      Sleep(1000);
                     }
                }
            }
            break;
      }

    case 2:
            {
                system("CLS");
                cout<<"1.SEARCH TRAIN BY TRAIN NUMBER\n\n";
                cout<<"2.SEARCH TRAIN BY TRAIN NAME\n\n";
                cout<<"3.BOOK TICKET BY FROM AND TO\n\n";
                cout<<"4.VIEW TICKET\n\n";
                cout<<"5.CANCELLATION\n\n";
                cout<<"6.BACK\n\n";
                int option;
                cin>>option;
                if(option>6 || option<1)
                  {cout<<"INVALID";
                    Sleep(800);
                   system("CLS");
                   }
                if(option==6)
                    continue;
                if(option==1)
                {
                    cout<<"ENTER YOUR TRAIN NUMBER\n\n";
                    char trainno[100];
                    cin>>trainno;
                    traintmp=train;
                    int count=0;
                    if(train==NULL)
                      {
                        count=1;
                       cout<<"NO TRAIN AVAILABLE \n\n";
                      }
                  if(train!=NULL)
                  {
                        while(traintmp!=NULL)//LOOP FOR FINDING OUT AND DISPLAYING THE TRAIN
                         {
                            if(strcmp(traintmp->trainnumber,trainno)==0)
                              {
                                 displaytraindetails();
                                  if(ticket==NULL)
                           {

                                 cout<<"NO OF SEATS AVAILABLE IN FIRST CLASS AC :";
                                 cout<<(traintmp->ac1.numberofseats*traintmp->ac1.numberofcoaches);
                                 cout<<"\n\n";
                                 cout<<"NO OF SEATS AVAILABLE IN SECOND CLASS AC :";
                                 cout<<(traintmp->ac2.numberofseats*traintmp->ac2.numberofcoaches);
                                 cout<<"\n\n";
                                 cout<<"NO OF SEATS AVAILABLE IN THIRD CLASS AC :";
                                 cout<<(traintmp->ac3.numberofseats*traintmp->ac3.numberofcoaches);
                                 cout<<"\n\n";
                                 cout<<"NO OF SEATS AVAILABLE IN SLEEPER :";
                                 cout<<(traintmp->sleeper.numberofseats*traintmp->sleeper.numberofcoaches);
                                 cout<<"\n\n";
                           }
                                 if(ticket!=NULL)
                                 {countseats(traintmp->trainnumber);
                                 cout<<"NO OF SEATS AVAILABLE IN FIRST CLASS AC :";
                                 cout<<(traintmp->ac1.numberofseats*traintmp->ac1.numberofcoaches)-av.ac1;
                                 cout<<"\n\n";
                                 cout<<"NO OF SEATS AVAILABLE IN SECOND CLASS AC:";
                                 cout<<(traintmp->ac2.numberofseats*traintmp->ac2.numberofcoaches)-av.ac2;
                                 cout<<"\n\n";
                                 cout<<"NO OF SEATS AVAILABLE IN THIRD CLASS AC :";
                                 cout<<(traintmp->ac3.numberofseats*traintmp->ac3.numberofcoaches)-av.ac3;
                                 cout<<"\n\n";
                                 cout<<"NO OF SEATS AVAILABLE IN SLEEPER :";
                                 cout<<(traintmp->sleeper.numberofseats*traintmp->sleeper.numberofcoaches)-av.sleeper;
                                 cout<<"\n\n";}
                                 count++;
                              }
                         traintmp=traintmp->next1;
                        }
                }
          if(count==0)
              cout<<"NO MATCH FOUND\n\n";
            Sleep(5000);
          }
   if(option==2)
   {
       cout<<"ENTER THE TRAIN NAME";
                    char trainna[100];
                    cin>>trainna;
                    int count=0;
                    traintmp=train;
                    if(train==NULL)
                      {
                       count=1;
                       cout<<"NO TRAIN AVAILABLE \n\n";
                      }
                  if(train!=NULL)
                      {
                        while(traintmp!=NULL)//LOOP FOR FINDING OUT THE TRAIN AND DISPLAYING IT
                         {
                            if(strcmp(traintmp->trainname,trainna)==0)
                              {    displaytraindetails();
                                   if(ticket==NULL)
                           {

                                 cout<<"NO OF SEATS AVAILABLE IN FIRST CLASS AC :";
                                 cout<<(traintmp->ac1.numberofseats*traintmp->ac1.numberofcoaches);
                                 cout<<"\n\n";
                                 cout<<"NO OF SEATS AVAILABLE IN SECOND CLASS AC :";
                                 cout<<(traintmp->ac2.numberofseats*traintmp->ac2.numberofcoaches);
                                 cout<<"\n\n";
                                 cout<<"NO OF SEATS AVAILABLE IN THIRD CLASS AC :";
                                 cout<<(traintmp->ac3.numberofseats*traintmp->ac3.numberofcoaches);
                                 cout<<"\n\n";
                                 cout<<"NO OF SEATS AVAILABLE IN SLEEPER :";
                                 cout<<(traintmp->sleeper.numberofseats*traintmp->sleeper.numberofcoaches);
                                 cout<<"\n\n";
                           }
                                 if(ticket!=NULL)
                                 {countseats(traintmp->trainnumber);
                                 cout<<"NO OF SEATS AVAILABLE IN FIRST CLASS Ac :";
                                 cout<<(traintmp->ac1.numberofseats*traintmp->ac1.numberofcoaches)-av.ac1;
                                 cout<<"\n\n";
                                 cout<<"NO OF SEATS AVAILABLE IN SECOND CLASS AC :";
                                 cout<<(traintmp->ac2.numberofseats*traintmp->ac2.numberofcoaches)-av.ac2;
                                 cout<<"\n\n";
                                 cout<<"NO OF SEATS AVAILABLE IN THIRD CLASS AC :";
                                 cout<<(traintmp->ac3.numberofseats*traintmp->ac3.numberofcoaches)-av.ac3;
                                 cout<<"\n\n";
                                 cout<<"NO OF SEATS AVAILABLE IN SLEEPER :";
                                 cout<<(traintmp->sleeper.numberofseats*traintmp->sleeper.numberofcoaches)-av.sleeper;
                                 cout<<"\n\n";}
                                   count++;
                              }
                         traintmp=traintmp->next1;

                       }
                  }
            if(count==0)
                 cout<<"NO MATCH FOUND\n\n";
                    Sleep(5000);
   }

           if(option==3)
           {
               char fromc[30],toc[30];
               traintmp=train;
               cout<<"ENTER FROM \n\n";
               cin>>fromc;
               cout<<"ENTER TO \n\n";
               cin>>toc;
               int count=0;
               if(train==NULL)
                  {

                    cout<<"NO TRAIN AVAILABLE\n\n";
                    count=0;
                  }
               while(traintmp!=NULL)
               {
                   if(strcmp(traintmp->from,fromc)==0)
                   {
                       if(strcmp(traintmp->to,toc)==0)
                       {
                          displaytraindetails();
                          if(ticket!=NULL)
                                 {countseats(traintmp->trainnumber);
                                 cout<<"NO OF SEATS AVAILABLE IN FIRST CLASS AC :";
                                 cout<<(traintmp->ac1.numberofseats*traintmp->ac1.numberofcoaches)-av.ac1;
                                 cout<<"\n\n";
                                 cout<<"NO OF SEATS AVAILABLE IN SECOND CLASS AC :";
                                 cout<<(traintmp->ac2.numberofseats*traintmp->ac2.numberofcoaches)-av.ac2;
                                 cout<<"\n\n";
                                 cout<<"NO OF SEATS AVAILABLE IN THIRD CLASS AC :";
                                 cout<<(traintmp->ac3.numberofseats*traintmp->ac3.numberofcoaches)-av.ac3;
                                 cout<<"\n\n";
                                 cout<<"NO OF SEATS AVAILABLE IN SLEEPER :";
                                 cout<<(traintmp->sleeper.numberofseats*traintmp->sleeper.numberofcoaches)-av.sleeper;
                                 cout<<"\n\n";}
                           if(ticket==NULL)
                           {

                                 cout<<"NO OF SEATS AVAILABLE IN FIRST CLASS AC :";
                                 cout<<(traintmp->ac1.numberofseats*traintmp->ac1.numberofcoaches);
                                 cout<<"\n\n";
                                 cout<<"NO OF SEATS AVAILABLE IN SECOND CLASS AC :";
                                 cout<<(traintmp->ac2.numberofseats*traintmp->ac2.numberofcoaches);
                                 cout<<"\n\n";
                                 cout<<"NO OF SEATS AVAILABLE IN THIRD CLASS AC :";
                                 cout<<(traintmp->ac3.numberofseats*traintmp->ac3.numberofcoaches);
                                 cout<<"\n\n";
                                 cout<<"NO OF SEATS AVAILABLE IN SLEEPER :";
                                 cout<<(traintmp->sleeper.numberofseats*traintmp->sleeper.numberofcoaches);
                                 cout<<"\n\n";
                           }
                          count++;

                       }
                  }
                    traintmp=traintmp->next1;
               }
                  if(count!=0)
                  {
                      cout<<"ENTER THE TRAIN NUMBER U WANT TO BOARD (CORRECTLY)";
                      char tno[30];
                      cin>>tno;

                      //it is the user responsibility to enter the details correctly
                      cout<<"1.FIRST CLASS AC\n";
                      cout<<"2.SECOND CLASS AC\n";
                      cout<<"3.THIRD CLASS AC\n";
                      cout<<"4.SLEEPER\n";
                      int option;

                      cin>>option;
                      traintmp=train;
                      if(ticket!=NULL)
                        rearrange(option,tno);
                     traintmp=train;
                     ckp=0;
                      traintp(tno);



                      if(ckp==1)
                      {
                          if(ticket!=NULL)
                          {
                                 countseats(traintmp->trainnumber);

                              tickettmp=ticket;
                              while(tickettmp->next2!=NULL)
                              {
                                  tickettmp=tickettmp->next2;
                              }
                              tickettmp->next2=new ticketdetails;
                              tickettmp=tickettmp->next2;
                          }
                          if(ticket==NULL)
                          {
                             ticket=new ticketdetails;
                             tickettmp=ticket;
                          }
                         strcpy(tickettmp->trainnumber,traintmp->trainnumber);
                          cout<<"PASSENGER NAME :";
                          cin>>tickettmp->passengername;
                          cout<<"\n\n";
                          cout<<"m/f:";
                          cin>>tickettmp->sex;
                          cout<<"\n\n";
                          cout<<"age:";
                          cin>>tickettmp->age;
                          cout<<"\n\n";
                          tickettmp->coach=option;

                          if(option==1)//allocating the coach number,seat number.
                          {
                              if(((traintmp->ac1.numberofseats)*(traintmp->ac1.numberofcoaches))-av.ac1>0)
                                 {tickettmp->status=1;
                                   tickettmp->coachno=((((traintmp->ac1.numberofseats)*(traintmp->ac1.numberofcoaches))-av.ac1-1)/traintmp->ac1.numberofseats)+1;
                                   tickettmp->seatno=((((traintmp->ac1.numberofseats)*(traintmp->ac1.numberofcoaches))-av.ac1-1)%traintmp->ac1.numberofseats)+1;
                                 }
                              else
                              {
                                  tickettmp->status=2;//STATUS=2 =>WAITING LIST
                              }                       //STATUS=1 =>RESERVED
                                                      //STATUS=0 =>CANCELLED
                          }
                            if(option==2)
                          {
                              if(((traintmp->ac2.numberofseats)*(traintmp->ac2.numberofcoaches))-av.ac2>0)
                                 {tickettmp->status=1;
                                   tickettmp->coachno=((((traintmp->ac2.numberofseats)*(traintmp->ac2.numberofcoaches))-av.ac2-1)/traintmp->ac2.numberofseats)+1;
                                   tickettmp->seatno=((((traintmp->ac2.numberofseats)*(traintmp->ac2.numberofcoaches))-av.ac2-1)%traintmp->ac2.numberofseats)+1;
                                 }
                              else
                              {
                                  tickettmp->status=2;
                              }
                          }
                            if(option==3)
                          {
                              if(((traintmp->ac3.numberofseats)*(traintmp->ac3.numberofcoaches))-av.ac3>0)
                                 {tickettmp->status=1;
                                   tickettmp->coachno=((((traintmp->ac3.numberofseats)*(traintmp->ac3.numberofcoaches))-av.ac3-1)/traintmp->ac3.numberofseats)+1;
                                   tickettmp->seatno=((((traintmp->ac3.numberofseats)*(traintmp->ac3.numberofcoaches))-av.ac3-1)%traintmp->ac3.numberofseats)+1;
                                 }
                              else
                              {
                                  tickettmp->status=2;
                              }
                          }
                          if(option==4)
                          {
                              if(((traintmp->sleeper.numberofseats)*(traintmp->sleeper.numberofcoaches))-av.sleeper>0)
                                 {tickettmp->status=1;
                                   tickettmp->coachno=((((traintmp->sleeper.numberofseats)*(traintmp->sleeper.numberofcoaches))-av.sleeper-1)/traintmp->sleeper.numberofseats)+1;
                                   tickettmp->seatno=((((traintmp->sleeper.numberofseats)*(traintmp->sleeper.numberofcoaches))-av.sleeper-1)%traintmp->sleeper.numberofseats)+1;
                                 }
                              else
                              {
                                  tickettmp->status=2;
                              }
                          }

                      }
                      if(ckp==0)
                        cout<<"INCORRECT";
                  }
                  if(count==0)
                      cout<<"NO MATCH FOUND\n\n";

          }
         if(option==4)
         {traintmp=train;
            while(traintmp!=NULL)
            {
                rearrange(1,traintmp->trainnumber);//THIS FUNCTION WILL SORT THE LINKLISST IN THE ORDER OF RESERVED TICKETS FOLLOWED BY WAITING LIST
                rearrange(2,traintmp->trainnumber);
                rearrange(3,traintmp->trainnumber);
                rearrange(4,traintmp->trainnumber);
                traintmp=traintmp->next1;
            }

          tickettmp=ticket;
       if(ticket==NULL)
          cout<<"NO TICKETS RESERVED\n";
      if(ticket!=NULL)
        {char passenger[30];
       int age,flag=0;
       cout<<"PASSENGER NAME";
       cin>>passenger;
       cout<<"AGE";
       cin>>age;

       while(tickettmp!=NULL)
       {
           if(strcmp(tickettmp->passengername,passenger)==0)
           {
               if(tickettmp->age==age)
               {traintmp=train;
                 traintp(tickettmp->trainnumber);
                cout<<"PASSENGER NAME :";
                flag++;
                cout<<tickettmp->passengername;
                cout<<"\n\n";
                cout<<"AGE :";
                cout<<tickettmp->age;
                cout<<"\n\n";
                displaytraindetails();

                if(tickettmp->coach==1&&tickettmp->status==1)
                {
                   cout<<"AC FIRST CLASS COACH No :"<<tickettmp->coachno;
                   cout<<"\n\n";
                   cout<<"SEAT NO :"<<tickettmp->seatno;
                   cout<<"\n\n";
                   cout<<"COST :"<<traintmp->ac1.cost;
                   cout<<"\n\n";
                   break;
                }
                if(tickettmp->coach==1&&tickettmp->status==2)
                {   waiting(1);
                    cout<<" IS UR WAITING LIST IN AC FIRST CLASS";
                    cout<<"\nCOST :"<<traintmp->ac1.cost<<"\n\n";
                    break;
                }
                if(tickettmp->coach==2&&tickettmp->status==1)
                {
                   cout<<"AC SECOND CLASS COACH NO :"<<tickettmp->coachno;
                   cout<<"\n\n";
                   cout<<"SEAT NO :"<<tickettmp->seatno;
                   cout<<"\n\n";
                   cout<<"\nCOST :"<<traintmp->ac2.cost<<"\n\n";
                   break;
                }
                if(tickettmp->coach==2&&tickettmp->status==2)
                {
                    waiting(2);
                    cout<<"IS UR WAITING LIST IN AC SECOND CLASS";
                    cout<<"\nCOST :"<<traintmp->ac2.cost<<"\n\n";
                    break;

                }
                  if(tickettmp->coach==3&&tickettmp->status==1)
                {
                   cout<<"AC THIRD CLASS COACH NO :"<<tickettmp->coachno;
                   cout<<"\n\n";
                   cout<<"SEAT NO :"<<tickettmp->seatno;
                   cout<<"\n\n";
                   cout<<"\nCOST :"<<traintmp->ac3.cost<<"\n\n";
                    break;
                }
                if(tickettmp->coach==3&&tickettmp->status==2)
                {
                    waiting(3);
                    cout<<"IS UR WAITING LIST IN AC THIRD CLASS";
                    cout<<"\nCOST :"<<traintmp->ac3.cost<<"\n\n";
                    break;
                }
                  if(tickettmp->coach==4&&tickettmp->status==1)
                {
                   cout<<"SLEEPER COACH NO :"<<tickettmp->coachno;
                   cout<<"\n\n";
                   cout<<"SEAT NO :"<<tickettmp->seatno;
                   cout<<"\n\n";
                   cout<<"\nCOST :"<<traintmp->sleeper.cost<<"\n\n";
                   break;
                }
                if(tickettmp->coach==4&&tickettmp->status==2)
                {
                    waiting(4);
                    cout<<"IS UR WAITING LIST IN SLEEPER CLASS";
                    cout<<"\nCOST :"<<traintmp->sleeper.cost<<"\n\n";
                    break;
                }
               }
          }

          tickettmp=tickettmp->next2;
       }
       if(flag==0)
        cout<<"NO MATCH FOUND";
       }

     }
     if(option==5)//CANCELLATION
     {
          tickettmp=ticket;
       if(ticket==NULL)
          cout<<"NO TICKETS RESERVED\n";
      if(ticket!=NULL)
        {char passenger[30];
       int age,flag=0;
       cout<<"PASSENGER NAME";
       cin>>passenger;
       cout<<"AGE";
       cin>>age;

     if(ticket->next2!=NULL)
       {while(tickettmp!=NULL)
       {
           if(strcmp(tickettmp->passengername,passenger)==0)
           {
               if(tickettmp->age==age)
               {traintmp=train;

              while(traintmp!=NULL)
               {
                 if(strcmp(traintmp->trainnumber,tickettmp->trainnumber)==0)
                     break;
                  traintmp=traintmp->next1;
               }
               flag++;
               tickettmp->status=0;//WE ARE GIVING STATUS=0 WHICH MEANS CANCELLED
               cout<<"CANCELLED";
               }
           }
           tickettmp=tickettmp->next2;
       }}
       else if(ticket->next2==NULL)
       {    flag++;
           cout<<"CANCELLED";
           ticket=NULL;
       }

       if(flag==0)
          cout<<"NO MATCH FOUND";
        }
        }
   }
}//switch
    }
  break;}


     case 1:

       {

         while(1)     //the menu wont close on its own .once closed the data is lost
          {
            system("cls");
            cout<<"1.ENTER THE DETAILS OF THE CURRENT TRAIN\n\n";
            cout<<"2.EDIT THE NUMBER OF PLATFORMS\n\n";
            cout<<"3.BACK\n\nENTR UR OPTION \n\n ";
            int option;
            cin>>option;
            if(option==3)
            break;

            switch(option)
                {
                    case 1:
                    {   system("cls");
                        cout<<"1.EXPRESS\n\n";
                        cout<<"2.LOCAL\n\n";
                        cout<<"3.GOODS\n\n";
                        cout<<"4.BACK\n\n";
                        cout<<"ENTER THE RESPECTIVE NUMBER\n";
                        int option;
                        cin>>option;
                        switch(option)
                            {
                                case 1:
                                        {   system("cls");
                                            nullallocation(1);//to allocate the platform to null when the time gets over
                                                 //for platform allocation//
                                            allocation(1);//entry of data for which only the pplatform is null
                                            Sleep(2000);
                                            break;
                                        }
                                case 2:
                                        {   system("cls");
                                            nullallocation(2);
                                            allocation(2);
                                            Sleep(2000);
                                            break;
                                        }
                                case 3:
                                        {   system("cls");
                                            nullallocation(3);
                                            allocation(3);
                                            Sleep(2000);
                                            break;
                                        }
                                case 4:
                                        {
                                            continue;
                                        }
                                default :
                                        {
                                            cout<<"ENTER THE OPTION CORRECTLY\n\n";
                                            Sleep(800);


                                        }
                            }
                        break;
                    }
                case 2:
                    {   cout<<"1. BACK\n\n2.CONTINUE\n\n";
                        int option;
                        cin>>option;
                        if(option==1)
                             continue;
                        else if(option==2)
                         {
                         system("cls");
                         cout<<"ENTER THE NUMBER OF EXPRESS PLATFORM\n\n";
                         cin>>platform1.expressplatform;
                         cout<<"ENTER THE NUMBER OF LOCAL PLATFORM\n\n";
                         cin>>platform1.localplatform;
                         cout<<"ENTER THE NUMBER OF GOODS PLATFORM\n\n";
                         cin>>platform1.goodsplatform;
                         continue;

                         }

                     }
                default :
                         {
                             cout<<"ENTER THE OPTION CORRECTLY\n\n";
                             Sleep(800);
                         }

                }



          }


     continue;
       }

    case 2:

       {system("CLS");
        while(1)
            {

            cout<<"\n1.DISPLAY ALL THE TRAIN AVAILABLE NOW\n\n";
            cout<<"\n2.SEARCH TRAIN BY TRAIN NAME\n\n";
            cout<<"\n3.SEARCH TRAIN BY TRAIN NUMBER\n\n";
            cout<<"\n4.BACK\n\n";
            int option;
            cin>>option;
            if(option==4)
                break;
            switch(option)
               {
                 case 1:
                          {   system("cls");
                              int k=0;
                              for(int i=0;i<platform1.expressplatform;i++)
                              {
                                  nullallocation(1);//THIS FUNCTION WILL ALLOCATE NULL IF TIME OF STAY OF THE TRAIN RUNS OUT
                                  if(expresstrain[i].platformnumber!=NULL)
                                  {
                                    k++;

                                  cout<<"   PLATFORM NUMBER:    "<<expresstrain[i].platformnumber<<"\n\n";

                                  cout<<"   TRAIN NAME:        "<<expresstrain[i].trainname<<"\n\n";

                                  cout<<"   TRAIN NUMBER:      "<< expresstrain[i].trainnumber<<"\n\n";

                                  cout<<"   TRAIN TYPE:        "<<"EXPRESS TRAIN     "<<"\n\n";

                                  cout<<"   SECONDS REMAINING : "<<(expresstrain[i].timeofstay+((expresstrain[i].start-clock())/(double)CLOCKS_PER_SEC))<<"\n\n";

                                  }

                              }



                              for(int i=0;i<platform1.localplatform;i++)
                              {
                                  nullallocation(2);
                                  if(localtrain[i].platformnumber!=NULL)
                                  {
                                    k++;
                                   cout<<"   PLATFORM NUMBER:    "<<localtrain[i].platformnumber+platform1.expressplatform<<"\n\n";

                                   cout<<"   TRAIN NAME:         "<<localtrain[i].trainname<<"\n\n";

                                   cout<<"   TRAIN NUMBER:       "<< localtrain[i].trainnumber<<"\n\n";

                                   cout<<"   TRAIN TYPE:         "<<" LOCAL  TRAIN        "<<"\n\n";

                                   cout<<"   SECONDS REMAINING : "<<localtrain[i].timeofstay+((localtrain[i].start-clock())/(double)CLOCKS_PER_SEC)<<"\n\n";

                                  }


                              }
                               for(int i=0;i<platform1.goodsplatform;i++)
                              {
                                  nullallocation(3);
                                  if(goodstrain[i].platformnumber!=NULL)
                                  {
                                     k++;
                                   cout<<"   PLATFORM NUMBER:    "<<goodstrain[i].platformnumber+platform1.expressplatform+platform1.localplatform<<"\n\n";

                                   cout<<"   TRAIN NAME:         "<<goodstrain[i].trainname<<"\n\n";

                                   cout<<"   TRAIN NUMBER:       "<< goodstrain[i].trainnumber<<"\n\n";

                                   cout<<"   TRAIN TYPE:         "<<"GOODS  TRAIN       "<<"\n\n";

                                   cout<<"   SECONDS REMAINING : "<<goodstrain[i].timeofstay+((goodstrain[i].start-clock())/(double)CLOCKS_PER_SEC)<<"\n\n";

                                  }


                              }
                              if(k==0)
                                 {cout<<"NO TRAIN AVAILABLE";
                                   Sleep(800);}
                             Sleep(800);
                              break;
                          }
                 case 2:
                      {   int k=0;
                          system("cls");
                           char tname[30];
                          cout<<"\nENTER THE TRAIN NAME\n";
                          cin>>tname;
                          nullallocation(1);
                          nullallocation(2);
                          nullallocation(3);
                          for(int i=0;i<platform1.expressplatform;i++)
                            {

                               if(expresstrain[i].platformnumber!=NULL)
                               {
                                   if(strcmp(tname,expresstrain[i].trainname)==0)
                                   {
                                        k++;

                                  cout<<"   PLATFORM NUMBER:    "<<expresstrain[i].platformnumber<<"\n\n";

                                  cout<<"   TRAIN NAME:         "<<expresstrain[i].trainname<<"\n\n";

                                  cout<<"   TRAIN NUMBER:       "<< expresstrain[i].trainnumber<<"\n\n";

                                  cout<<"   TRAIN TYPE:         "<< "EXPRESS TRAIN     "<<"\n\n";

                                  cout<<"   SECONDS REMAINING : "<<expresstrain[i].timeofstay+((expresstrain[i].start-clock())/(double)CLOCKS_PER_SEC)<<"\n\n";
                                   }
                               }

                            }
                            for(int i=0;i<platform1.localplatform;i++)
                            {
                                if(localtrain[i].platformnumber!=NULL)
                                {   if(strcmp(tname,localtrain[i].trainname)==0)
                                     {k++;

                                   cout<<"   PLATFORM NUMBER:    "<<localtrain[i].platformnumber+platform1.expressplatform<<"\n\n";

                                   cout<<"   TRAIN NAME:         "<<localtrain[i].trainname<<"\n\n";

                                   cout<<"   TRAIN NUMBER:       "<< localtrain[i].trainnumber<<"\n\n";

                                   cout<<"   TRAIN TYPE   :      "<<" LOCAL  TRAIN        "<<"\n\n";

                                   cout<<"   SECONDS REMAINING : "<<localtrain[i].timeofstay+((localtrain[i].start-clock())/(double)CLOCKS_PER_SEC)<<"\n\n";

                                     }
                                }

                            }
                            for(int i=0;i<platform1.goodsplatform;i++)
                            {
                                if(goodstrain[i].platformnumber!=NULL)
                                {
                                  if(strcmp(tname,goodstrain[i].trainname)==0)
                                   {k++;

                                   cout<<"   PLATFORM NUMBER:    "<<goodstrain[i].platformnumber+platform1.expressplatform+platform1.localplatform<<"\n\n";

                                   cout<<"   TRAIN NAME:         "<<goodstrain[i].trainname<<"\n\n";

                                   cout<<"   TRAIN NUMBER:       "<< goodstrain[i].trainnumber<<"\n\n";

                                   cout<<"   TRAIN TYPE:         "<< "GOODS  TRAIN        "<<"\n\n";

                                   cout<<"   SECONDS REMAINING : "<<goodstrain[i].timeofstay+((goodstrain[i].start-clock())/(double)CLOCKS_PER_SEC)<<"\n\n";
                                   }
                                }
                            }
                                 if(k==0)
                                    {cout<<"NO MATCH FOUND";
                                     Sleep(800);
                                    }
                            Sleep(800);
                         break;
                      }
                 case 3:
                        { int k=0;
                            system("cls");
                            int tnumber;
                            cout<<"\nENTER THE TRAIN NUMBER\n";
                            cin>>tnumber;
                            nullallocation(1);
                          nullallocation(2);
                          nullallocation(3);
                          for(int i=0;i<platform1.expressplatform;i++)
                            {

                               if(expresstrain[i].platformnumber!=NULL)
                               {
                                   if(expresstrain[i].trainnumber==tnumber)
                                   {
                                              k++;

                                  cout<<"   PLATFORM NUMBER:    "<<expresstrain[i].platformnumber<<"\n\n";

                                  cout<<"   TRAIN NAME:         "<<expresstrain[i].trainname<<"\n\n";

                                  cout<<"   TRAIN NUMBER:       "<<expresstrain[i].trainnumber<<"\n\n";

                                  cout<<"   TRAIN TYPE :        "<<"EXPRESS TRAIN      "<<"\n\n";

                                  cout<<"   SECONDS REMAINING : "<<expresstrain[i].timeofstay+((expresstrain[i].start-clock()))/(double)CLOCKS_PER_SEC<<"\n\n";
                                   }
                               }

                            }
                            for(int i=0;i<platform1.localplatform;i++)
                            {
                                if(localtrain[i].platformnumber!=NULL)
                                {   if(localtrain[i].trainnumber==tnumber)
                                     { k++;

                                   cout<<"   PLATFORM NUMBER:   "<< localtrain[i].platformnumber+platform1.expressplatform<<"\n\n";

                                   cout<<"   TRAIN NAME:        "<< localtrain[i].trainname<<"\n\n";

                                   cout<<"   TRAIN NUMBER:      "<< localtrain[i].trainnumber<<"\n\n";

                                   cout<<"   TRAIN TYPE         "<<" LOCAL  TRAIN       "<<"\n\n";

                                   cout<<"   SECONDS REMAINING :"<<localtrain[i].timeofstay+((localtrain[i].start-clock())/(double)CLOCKS_PER_SEC)<<"\n\n";

                                     }
                                }

                            }
                            for(int i=0;i<platform1.goodsplatform;i++)
                            {
                                if(goodstrain[i].platformnumber!=NULL)
                                {
                                  if(tnumber==goodstrain[i].trainnumber)
                                   {
                                       k++;
                                   cout<<"   PLATFORM NUMBER:     "<<goodstrain[i].platformnumber+platform1.expressplatform+platform1.localplatform<<"\n\n";

                                   cout<<"   TRAIN NAME:          "<<goodstrain[i].trainname<<"\n\n";

                                   cout<<"   TRAIN NUMBER:        "<< goodstrain[i].trainnumber<<"\n\n";

                                   cout<<"   TRAIN TYPE :         "<< "GOODS  TRAIN         "<<"\n\n";

                                   cout<<"   SECONDS REMAINING :  "<<goodstrain[i].timeofstay+((goodstrain[i].start-clock())/(double)CLOCKS_PER_SEC)<<"\n\n";

                                   }

                                }
                            }
                        if(k==0)
                          {cout<<"NO MATCH FOUND";
                           Sleep(800);
                          }
                          Sleep(800);
                          break;
                        }

                 default :
                    {
                        cout<<"ENTER THE OPTION CORRECTLY\n\n";
                        Sleep(800);
                        system("CLS");
                    }
               }


       }
         continue;
       }

   default :
         {
             cout<<"ENTER THE OPTION CORRECTLY\n\n";
             Sleep(800);
         }

     }
   }
   return 0;
 }

 void allocation(int a)
        {
            if(a==1)//for express train input
              {
                for(int i=0;i<platform1.expressplatform;i++)


                  {
                   if(expresstrain[i].platformnumber==NULL)//if and only if the elements platform is null
                                                          //the entry is made
                      {
                        expresstrain[i].start=clock();
                        expresstrain[i].platformnumber=i+1;
                        cout<<"ENTER THE TRAIN NUMBER\n\n";
                        cin>>expresstrain[i].trainnumber;
                        cout<<"ENTER THE TRAIN NAME\n\n";
                        cin>>expresstrain[i].trainname;
                        cout<<"ENTER THE TIME OF STAY OF THE TRAIN FROM NOW\n\n";
                        cin>>expresstrain[i].timeofstay;
                        expresstrain[i].traintype=1;
                        cout<<"ALLOCATED PLATFORM IS:"<<i+1<<endl<<endl;
                        break;
                      }
                    if(i==(platform1.expressplatform-1)&&expresstrain[i].platformnumber!=NULL)
                        {cout<<"THE PLATFORMS ARE NOT VACANT\n\n";//if all are allocated then there is no
                                                                  //no vacancy that is i reaches the max
                        }
                   }
               }

              if(a==2)
              {
                for(int i=0;i<platform1.localplatform;i++)


                  {
                   if(localtrain[i].platformnumber==NULL)
                      {
                        localtrain[i].start=clock();
                        localtrain[i].platformnumber=i+1;
                        cout<<"ENTER THE TRAIN NUMBER\n\n";
                        cin>>localtrain[i].trainnumber;
                        cout<<"ENTER THE TRAIN NAME\n\n";
                        cin>>localtrain[i].trainname;
                        cout<<"ENTER THE TIME OF STAY OF THE TRAIN FROM NOW\n\n";
                        cin>>localtrain[i].timeofstay;
                        localtrain[i].traintype=2;
                        cout<<"ALLOCATED PLAFORM IS:"<<i+1+platform1.expressplatform<<endl<<endl;
                        break;

                      }

                    if(localtrain[i].platformnumber!=NULL&&i==platform1.localplatform-1)
                       {

                        cout<<"THERE IS NO PLATFORM VACCANT\n\n";
                       }
                  }
               }

               if(a==3)
              {
                for(int i=0;i<platform1.goodsplatform;i++)


                  {
                   if(goodstrain[i].platformnumber==NULL)
                      {
                        goodstrain[i].start=clock();
                        goodstrain[i].platformnumber=i+1;
                        cout<<"ENTER THE TRAIN NUMBER\n\n";
                        cin>>goodstrain[i].trainnumber;
                        cout<<"ENTER THE TRAIN NAME\n\n";
                        cin>>goodstrain[i].trainname;
                        cout<<"ENTER THE TIME OF STAY OF THE TRAIN FROM NOW\n\n";
                        cin>>goodstrain[i].timeofstay;
                        goodstrain[i].traintype=3;
                        cout<<"ALLOCATED PLATFORM IS:"<<i+1+platform1.localplatform+platform1.expressplatform<<endl<<endl;
                        break;

                      }
                    if(goodstrain[i].platformnumber!=NULL&&i==platform1.goodsplatform-1)
                        {

                        cout<<"NO PLATFORM VACCANT\n\n";
                        }
                   }
               }


        }


 void nullallocation(int a)//allocates null to the platform whenever the time of stay expires
 {
     if(a==1)
     {
         for(int i=0;i<platform1.expressplatform;i++)
         {
             if(expresstrain[i].platformnumber!=NULL)//since the constructor allocates null to every element
             {
                   if(((clock()-expresstrain[i].start)/(double)CLOCKS_PER_SEC)>expresstrain[i].timeofstay)
                          expresstrain[i].platformnumber=NULL;
             }
         }
     }

  if(a==2)
     {
         for(int i=0;i<platform1.localplatform;i++)
         {
             if(localtrain[i].platformnumber!=NULL)
             {
                   if(((clock()-localtrain[i].start)/(double)CLOCKS_PER_SEC)>localtrain[i].timeofstay)
                          localtrain[i].platformnumber=NULL;
             }
         }
     }

  if(a==3)
     {
         for(int i=0;i<platform1.goodsplatform;i++)
         {
             if(goodstrain[i].platformnumber!=NULL)
             {
                   if(((clock()-goodstrain[i].start)/(double)CLOCKS_PER_SEC)>goodstrain[i].timeofstay)
                          goodstrain[i].platformnumber=NULL;
             }
         }
     }

 }
